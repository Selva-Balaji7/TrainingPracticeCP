# Docs moved

The old Appium 1.x docs used to be in this directory. Now, they are available only on the [1.x
branch](https://github.com/appium/appium/tree/1.x/docs).

Appium 2.x docs are located in [packages/appium/docs](../packages/appium/docs) in this repo.

module.exports = require('./build/lib/plugin');

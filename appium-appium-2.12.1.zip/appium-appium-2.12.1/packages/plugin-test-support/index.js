module.exports = require('./build/lib/harness');

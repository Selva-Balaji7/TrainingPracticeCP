'use strict';

module.exports = require('./build/lib/plugin');

# @appium/fake-plugin

> Fake Appium plugin for internal testing

## License

Apache-2.0

module.exports = {
  notFind: function () { // eslint-disable-line object-shorthand
    return [];
  }
};

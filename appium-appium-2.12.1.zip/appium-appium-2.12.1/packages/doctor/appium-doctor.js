#!/usr/bin/env node

module.exports = require('./build/bin/appium-doctor');

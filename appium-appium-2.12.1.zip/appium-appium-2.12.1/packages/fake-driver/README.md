# @appium/fake-driver

> Fake Appium driver for internal testing

## License

Apache-2.0

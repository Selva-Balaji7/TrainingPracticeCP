/* eslint-disable @typescript-eslint/no-var-requires */
const {EnvVarAndPathCheck} = require('./common');

const fakeCheck2 = new EnvVarAndPathCheck('FAKE2');

module.exports = {fakeCheck2};

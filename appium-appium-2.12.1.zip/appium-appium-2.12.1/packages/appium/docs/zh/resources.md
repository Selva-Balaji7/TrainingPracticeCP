---
hide:
  - navigation
  - toc

title: 其他资源
---

在这里，您可以找到网络上其他 Appium 资源的链接:

## 网站

- [Appium Pro](https://appiumpro.com) - 是Appium其中一名维护者乔纳森-利普斯（Jonathan Lipps）撰写的博客和时事通讯。
撰写的博客和时事通讯，其中包含大量实用指南

## 在线课程

- [Appium 和 Selenium 基础](https://ui.headspin.io/university/learn/appium-selenium-fundamentals-2020) - Jonathan Lipps 编写的学习 Python、Selenium 和 Appium 的综合视频课程
- [使用 Appium 实现移动测试自动化](https://testautomationu.applitools.com/appium-java-tutorial/) - 由 Moataz Nabil 制作的视频课程
- [高级Appoium](https://www.linkedin.com/learning/advanced-appium) - 乔纳森-利普斯（Jonathan Lipps）的视频课程

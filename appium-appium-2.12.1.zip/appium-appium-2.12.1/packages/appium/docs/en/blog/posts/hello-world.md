---
authors:
  - jlipps
date: 2024-03-07
---

# Hello World!

This is the first post in the Appium blog. There's not much to see here yet. We're creating this
space so we can make announcements or post other news, or information about events, that don't
really fit inside the documentation itself.

<!-- more -->

Stay tuned for more!

import log from './lib/log';
export type * from './lib/types';

export {log};
export default log;
